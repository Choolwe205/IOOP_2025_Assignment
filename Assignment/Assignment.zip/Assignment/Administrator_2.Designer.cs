﻿namespace Assignment
{
    partial class Administrator_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.users_btn = new System.Windows.Forms.Button();
            this.res_btn = new System.Windows.Forms.Button();
            this.Chef_btn = new System.Windows.Forms.Button();
            this.sales_btn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // users_btn
            // 
            this.users_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.users_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.users_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.users_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.users_btn.ForeColor = System.Drawing.Color.Black;
            this.users_btn.Location = new System.Drawing.Point(12, 350);
            this.users_btn.Name = "users_btn";
            this.users_btn.Size = new System.Drawing.Size(232, 84);
            this.users_btn.TabIndex = 10;
            this.users_btn.Text = "Users";
            this.users_btn.UseVisualStyleBackColor = false;
            // 
            // res_btn
            // 
            this.res_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.res_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.res_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.res_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.res_btn.ForeColor = System.Drawing.Color.Black;
            this.res_btn.Location = new System.Drawing.Point(12, 268);
            this.res_btn.Name = "res_btn";
            this.res_btn.Size = new System.Drawing.Size(232, 84);
            this.res_btn.TabIndex = 9;
            this.res_btn.Text = "Reservation Coordinators";
            this.res_btn.UseVisualStyleBackColor = false;
            // 
            // Chef_btn
            // 
            this.Chef_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.Chef_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Chef_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Chef_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chef_btn.ForeColor = System.Drawing.Color.Black;
            this.Chef_btn.Location = new System.Drawing.Point(12, 186);
            this.Chef_btn.Name = "Chef_btn";
            this.Chef_btn.Size = new System.Drawing.Size(232, 84);
            this.Chef_btn.TabIndex = 8;
            this.Chef_btn.Text = "Chefs";
            this.Chef_btn.UseVisualStyleBackColor = false;
            // 
            // sales_btn
            // 
            this.sales_btn.AllowDrop = true;
            this.sales_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.sales_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.sales_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sales_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sales_btn.ForeColor = System.Drawing.Color.Black;
            this.sales_btn.Location = new System.Drawing.Point(12, 22);
            this.sales_btn.Name = "sales_btn";
            this.sales_btn.Size = new System.Drawing.Size(232, 84);
            this.sales_btn.TabIndex = 7;
            this.sales_btn.Text = "Sales";
            this.sales_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.sales_btn.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(12, 104);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(232, 84);
            this.button2.TabIndex = 6;
            this.button2.Text = "Managers";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // Administrator_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.users_btn);
            this.Controls.Add(this.res_btn);
            this.Controls.Add(this.Chef_btn);
            this.Controls.Add(this.sales_btn);
            this.Controls.Add(this.button2);
            this.Name = "Administrator_2";
            this.Text = "Administrator_2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button users_btn;
        private System.Windows.Forms.Button res_btn;
        private System.Windows.Forms.Button Chef_btn;
        private System.Windows.Forms.Button sales_btn;
        private System.Windows.Forms.Button button2;
    }
}