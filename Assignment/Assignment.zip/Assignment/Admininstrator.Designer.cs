﻿namespace Assignment
{
    partial class Admininstrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admininstrator));
            this.SideBar = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.sales_btn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Expand = new System.Windows.Forms.Button();
            this.minimize = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.Maximize = new System.Windows.Forms.Button();
            this.SideBar_Timer = new System.Windows.Forms.Timer(this.components);
            this.Main_view_pannel = new System.Windows.Forms.Panel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.Email_ID_lbl = new System.Windows.Forms.Label();
            this.SideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // SideBar
            // 
            this.SideBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.SideBar.BackColor = System.Drawing.Color.Green;
            this.SideBar.Controls.Add(this.Email_ID_lbl);
            this.SideBar.Controls.Add(this.linkLabel1);
            this.SideBar.Controls.Add(this.pictureBox1);
            this.SideBar.Controls.Add(this.button4);
            this.SideBar.Controls.Add(this.button3);
            this.SideBar.Controls.Add(this.button2);
            this.SideBar.Controls.Add(this.button1);
            this.SideBar.Controls.Add(this.sales_btn);
            this.SideBar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.SideBar.Location = new System.Drawing.Point(0, 0);
            this.SideBar.Name = "SideBar";
            this.SideBar.Size = new System.Drawing.Size(58, 924);
            this.SideBar.TabIndex = 0;
            this.SideBar.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(109, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 110);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button4
            // 
            this.button4.AllowDrop = true;
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button4.Location = new System.Drawing.Point(4, 413);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(381, 47);
            this.button4.TabIndex = 5;
            this.button4.Text = "   Users";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.AllowDrop = true;
            this.button3.BackColor = System.Drawing.Color.Green;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button3.Location = new System.Drawing.Point(4, 369);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(381, 47);
            this.button3.TabIndex = 3;
            this.button3.Text = "   Reservation Corrdinators";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.AllowDrop = true;
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button2.Location = new System.Drawing.Point(4, 327);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(381, 47);
            this.button2.TabIndex = 4;
            this.button2.Text = "   Chefs";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.AllowDrop = true;
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button1.Location = new System.Drawing.Point(4, 283);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(381, 47);
            this.button1.TabIndex = 3;
            this.button1.Text = "   Managers";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // sales_btn
            // 
            this.sales_btn.AllowDrop = true;
            this.sales_btn.BackColor = System.Drawing.Color.Green;
            this.sales_btn.FlatAppearance.BorderSize = 0;
            this.sales_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sales_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sales_btn.ForeColor = System.Drawing.Color.White;
            this.sales_btn.Image = ((System.Drawing.Image)(resources.GetObject("sales_btn.Image")));
            this.sales_btn.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.sales_btn.Location = new System.Drawing.Point(4, 240);
            this.sales_btn.Name = "sales_btn";
            this.sales_btn.Size = new System.Drawing.Size(381, 47);
            this.sales_btn.TabIndex = 2;
            this.sales_btn.Text = "   Sales";
            this.sales_btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sales_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.sales_btn.UseVisualStyleBackColor = false;
            this.sales_btn.Click += new System.EventHandler(this.sales_btn_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.Expand);
            this.panel3.Controls.Add(this.minimize);
            this.panel3.Controls.Add(this.Close);
            this.panel3.Controls.Add(this.Maximize);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1530, 52);
            this.panel3.TabIndex = 2;
            // 
            // Expand
            // 
            this.Expand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Expand.FlatAppearance.BorderSize = 0;
            this.Expand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Expand.Image = ((System.Drawing.Image)(resources.GetObject("Expand.Image")));
            this.Expand.Location = new System.Drawing.Point(0, 4);
            this.Expand.Name = "Expand";
            this.Expand.Size = new System.Drawing.Size(58, 45);
            this.Expand.TabIndex = 3;
            this.Expand.UseVisualStyleBackColor = false;
            this.Expand.Click += new System.EventHandler(this.Expand_Click);
            // 
            // minimize
            // 
            this.minimize.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.minimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.minimize.FlatAppearance.BorderSize = 0;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Image = ((System.Drawing.Image)(resources.GetObject("minimize.Image")));
            this.minimize.Location = new System.Drawing.Point(1361, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(58, 52);
            this.minimize.TabIndex = 0;
            this.minimize.UseVisualStyleBackColor = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // Close
            // 
            this.Close.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Close.FlatAppearance.BorderSize = 0;
            this.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Close.Image = ((System.Drawing.Image)(resources.GetObject("Close.Image")));
            this.Close.Location = new System.Drawing.Point(1479, 0);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(51, 52);
            this.Close.TabIndex = 2;
            this.Close.UseVisualStyleBackColor = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Maximize
            // 
            this.Maximize.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Maximize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Maximize.FlatAppearance.BorderSize = 0;
            this.Maximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Maximize.Image = ((System.Drawing.Image)(resources.GetObject("Maximize.Image")));
            this.Maximize.Location = new System.Drawing.Point(1417, 0);
            this.Maximize.Name = "Maximize";
            this.Maximize.Size = new System.Drawing.Size(56, 52);
            this.Maximize.TabIndex = 1;
            this.Maximize.UseVisualStyleBackColor = false;
            this.Maximize.Click += new System.EventHandler(this.Maximize_Click);
            // 
            // SideBar_Timer
            // 
            this.SideBar_Timer.Interval = 1;
            this.SideBar_Timer.Tick += new System.EventHandler(this.SideBar_Timer_Tick);
            // 
            // Main_view_pannel
            // 
            this.Main_view_pannel.Location = new System.Drawing.Point(380, 58);
            this.Main_view_pannel.Name = "Main_view_pannel";
            this.Main_view_pannel.Size = new System.Drawing.Size(1146, 650);
            this.Main_view_pannel.TabIndex = 3;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(0, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(68, 16);
            this.linkLabel1.TabIndex = 7;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "linkLabel1";
            // 
            // Email_ID_lbl
            // 
            this.Email_ID_lbl.AutoSize = true;
            this.Email_ID_lbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Email_ID_lbl.Location = new System.Drawing.Point(82, 185);
            this.Email_ID_lbl.Name = "Email_ID_lbl";
            this.Email_ID_lbl.Size = new System.Drawing.Size(44, 16);
            this.Email_ID_lbl.TabIndex = 8;
            this.Email_ID_lbl.Text = "label1";
            // 
            // Admininstrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1529, 708);
            this.Controls.Add(this.Main_view_pannel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.SideBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admininstrator";
            this.Text = "Admininstrator";
            this.Load += new System.EventHandler(this.Admininstrator_Load);
            this.SideBar.ResumeLayout(false);
            this.SideBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SideBar;
        private System.Windows.Forms.Button sales_btn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button Maximize;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer SideBar_Timer;
        private System.Windows.Forms.Button Expand;
        private System.Windows.Forms.Panel Main_view_pannel;
        private System.Windows.Forms.Label Email_ID_lbl;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}